
package finalprojectjava;

import java.util.Scanner;
public class Grade {
    String studentname,lesson;
    int grade;
    void add_Grade(){
        Scanner inpute=new Scanner(System.in);
        System.out.println("studentname");
        studentname=inpute.nextLine();
         System.out.println("lesson");
       lesson =inpute.nextLine();
         System.out.println("grade");
        grade=inpute.nextInt();
    }
    void show_Grade(){
        System.out.println(studentname+"\t"+lesson+"\t"+grade+"\t");
    }
}
