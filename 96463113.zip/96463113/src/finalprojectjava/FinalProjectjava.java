/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectjava;

import java.util.Calendar;
import java.util.Scanner;

/**
 *
 * @author narges
 */
public class FinalProjectjava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
        System.out.println("------------------------------------------------");
        int count1=4, count2=4, count3=4, count4=4, count5=4, count6=4;
        System.out.println("-------------------------------------------------");
        System.out.println("school manegment system");
        System.out.println("-------------------------------------------------");
    
    teacher[]t=new teacher[25];
    student[]s=new student[100];
    Grade[]g=new Grade[200];
    studentlist[]st=new studentlist[152];
    clas[]c=new clas[158];
    int i;
    for(i=0;i<25;i++)
    t[i]=new teacher();

     for(i=0;i<100;i++)
    s[i]=new student();   
     
     for(i=0;i<20;i++)
    g[i]=new Grade();   
    for(i=0;i<152;i++)
     st[i]=new studentlist();
    for(i=0;i<158;i++) {
     c[i]=new clas();
    }  
    
    t[0].id="21";t[0].name="narges";t[0].lesson="fizik/zaban";t[0].age=25;;t[0].room=17/25;
    t[1].id="25";t[1].name="zahra";t[1].lesson="amar/shimi/dini";t[1].age=45;t[1].room=25/15/14;
    t[2].id="88";t[2].name="neda";t[2].lesson="shimi";t[2].age=35;t[2].room=65;
    t[3].id="96";t[3].name="hoda";t[3].lesson="madar";t[3].age=39;t[3].room=18;
    
    s[0].name="jalal";s[1].lesson="arabi/zaban/amar";s[0].room="";s[0].age=15;s[0].grade=16/17/15 ;
    s[1].name="ali";s[1].lesson="madar/amar/shimi";s[1].room="";s[1].age=15;s[1].grade=18/16/15;
    s[2].name="mohamad";s[2].lesson="madar/fizik/shimi";s[2].room="";s[2].age=16;s[2].grade=11/15/18 ;
    s[3].name="vali";s[3].lesson="arabi/farsi/fizik";s[3].room="";s[3].age=18;s[3].grade=12/14/15 ;

   g[0].studentname="sara";g[0].lesson="arabi";g[0].grade=15;
   g[1].studentname="hosein";g[1].lesson="dini";g[1].grade=15;
   g[2].studentname="akbar";g[2].lesson="zaban";g[2].grade=17;
   g[3].studentname="mona";g[3].lesson="shimi";g[2].grade=18;
   
   st[0].clas="fizik";st[0].student="jalal/ali/hosein";
   st[1].clas="amar";st[1].student="jalal/neda/hoda";
   st[2].clas="shimi";st[2].student="mohamad/ali/vali";
   st[3].clas="madar";st[3].student="mohamad/ali/hasan";
   c[0].clas="zaban";c[0].teacher="narges";
   c[1].clas="shimi";c[1].teacher="neda";
   c[2].clas="fizik";c[2].teacher="hoda";
   c[3].clas="farsi";c[3].teacher="zahra";
        Scanner inpute=new Scanner(System.in);
        int choice,j,c1,status=1,s1=1,s2=1,s3=1,s4=1,s5=1,s6=1,h;
        while(status==1){
         
            System.out.println("1.manager 2.teacher 3.student   4.exite"  );
          choice=inpute.nextInt();
         switch(choice){
          case 1:
          {
              System.out.println("manager section");
              s1=1;
              while (s1==1) {  
                  System.out.println("1.newteacher 2.teacherlist  3.newstudent 4.studentlist ");    
                  c1=inpute.nextInt();
                  switch(c1){
                  case 1 :{
                      t[count1].new_teacher();
                      count1++;
                      break;
                  } 
                  case 2:{                    
                      System.out.println("id\t name\t lesson \t room \t age   ");                       
                   for(j=0;j<count1;j++)  {
                    t[j].teacher_info();
                   } 
                   break;   
                  }
                  case 3:{
                  s[count2].new_student(); 
                  count2++;
                  break;
                  }
                  case 4:{
                      System.out.println("id\t name\t lesson\t room\t agr\t grade\t");
                      for(j=0;j<count2;j++){
                          s[j].student_info();
                      }
                      break;
                  }
                  
              }
                  System.out.println("  enter 1");  
                  s1=inpute.nextInt();
                 
              }
              break;
          }
         case 2:{
             System.out.println("    teacher ");
             s2=1;
             while (s2==1) {                 
                 System.out.println("1.nargesprogram 2.zahraprogram 3.nedaprogram 4.hodaprogram "
                  + " 5.nargesstudentlist 6.zahrastudentlist 7.hodastudentlist 8.neda studentlist"
                  + "9.gradenarges 10.nargesgradelist 11.gradezahra  12.zahragradelist 13.hodagrade"
                         + "14.hodagradelist 15.nedagrade 16.nedagradelist");   
                 c1=inpute.nextInt();
 
                switch(c1){
                            case 1:{
                            if(c1==1)
                          for(j=0;j<count1;j++)
                              t[0].teacher_info();
                          
                            break;} 
                        case 2:{
                           if(c1==2){
                           for(j=0;j<count4;j++)  
                            t[1] .teacher_info();
                           }
                          break;}
                        case 3:{
                          if(c1==3){
                       for(j=0;j<count1;j++) 
                        t[2].teacher_info();
                          }
                       break;}
                          case 4:{
                              if(c1==4)
                          for(j=0;j<count1;j++){
                          t[3].teacher_info();
                        }
                          break;
                }
                case 5:{
                if(c1==5){
                 for(j=0;j<count4;j++) 
                    st[0].studentlist();
                  
                }
                break;
             }
                case 6:{
                  if(c1==6){
                 for(j=0;j<count4;j++) 
                    st[1].studentlist();   
                }
                  break;}
                case 7:{
                   if(c1==7){
                 for(j=0;j<count4;j++) 
                    st[2].studentlist(); 
                }
                   break;}
                case 8:{
                 if(c1==8){
                 for(j=0;j<count4;j++) 
                    st[3].studentlist(); 
                }   
                 break;
                }
                
              case 9 :{
                      g[count3].add_Grade();
                      count3++;
                      break;
                  } 
                  case 10:{                    
                      System.out.println("studentname\t lesson\t grade\t   ");                       
                   for(j=0;j<count3;j++)  {
                    g[j].show_Grade();
                   } 
                   break;   
                  }  
                   case 11 :{
                      g[count3].add_Grade();
                      count3++;
                      break;
                  } 
                  case 12:{                    
                      System.out.println("studentname\t lesson\t grade\t   ");                       
                   for(j=0;j<count3;j++)  {
                    g[j].show_Grade();
                   } 
                   break;   
                  } 
                     case 13:{
                      g[count3].add_Grade();
                      count3++;
                      break;
                  } 
                  case 14:{                    
                      System.out.println("studentname\t lesson\t grade\t   ");                       
                   for(j=0;j<count3;j++)  {
                    g[j].show_Grade();
                   } 
                   break;   
                  }
                    case 15:{
                      g[count3].add_Grade();
                      count3++;
                      break;
                  } 
                  case 16:{                    
                      System.out.println("studentname\t lesson\t grade\t   ");                       
                   for(j=0;j<count3;j++)  {
                    g[j].show_Grade();
                   } 
                   break;   
                  }                            

                }
                 System.out.println("enter 1"); 
         s2=inpute.nextInt();
          
             } 
        
         }
         case 3:{
          System.out.println("    student ");
             s3=1;
             while (s3==1) {                 
                 System.out.println("1.jalalprogram 2.aliprogram 3.mohamadprogram 4.valiprogram 5.jalalclas "
                   + " 6.listjalalclas  7.aliclas 8.listaliclas 9.mohamad clas 10.listmohamadclas"
                         + "11.valiclas 12listvaliclas");   
                 c1=inpute.nextInt();
 
                switch(c1){
                            case 1:{
                            if(c1==1)
                          for(j=0;j<count2;j++)
                              s[0].student_info();
                          
                            break;} 
                        case 2:{
                           if(c1==2){
                           for(j=0;j<count2;j++)  
                            s[1] .student_info();
                           }
                          break;}
                        case 3:{
                          if(c1==3){
                       for(j=0;j<count2;j++) 
                        s[2].student_info();
                          }
                       break;}
                          case 4:{
                              if(c1==4)
                          for(j=0;j<count3;j++){
                          s[3].student_info();
                        }
                          break;
                }
                               case 5 :{
                      c[count5].new_clas();
                      count5++;
                      break;
                  } 
                  case 6:{                    
                      System.out.println("clas\t teacher\t    ");                       
                   for(j=0;j<count5;j++)  {
                    c[j].clas_info();
                   } 
                   break;   
                  }  
                   case 7 :{
                      c[count5].new_clas();
                      count5++;
                      break;
                  } 
                  case 8:{                    
                      System.out.println("clas\t teacher\t   ");                       
                   for(j=0;j<count5;j++)  {
                    c[j].clas_info();
                   } 
                   break;   
                  } 
                     case 9:{
                      c[count5].new_clas();
                      count5++;
                      break;
                  } 
                  case 10:{                    
                      System.out.println("clas\t teacher   ");                       
                   for(j=0;j<count5;j++)  {
                    c[j].clas_info();
                   } 
                   break;   
                  }
                    case 11:{
                      c[count5].new_clas();
                      count5++;
                      break;
                  } 
                  case 12:{                    
                      System.out.println("clas\t teacher\t    ");                       
                   for(j=0;j<count3;j++)  {
                    c[j].clas_info();
                   } 
                   break;   
                  }
         }
                 System.out.println("enter 1");
                 s3=inpute.nextInt();
         } 
        
        }}}
      
    }}
                
                 
             
        
        
        
         