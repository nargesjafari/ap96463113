/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectjava;

import java.util.Scanner;

/**
 *
 * @author narges
 */
public class clas{
    String clas, teacher;
     void new_clas(){
        Scanner input=new Scanner(System.in);
        System.out.println("clas");
        clas=input.nextLine();
        System.out.println("teacher");
        teacher=input.nextLine();
     }
      void clas_info(){
        System.out.println(clas+"\t"+teacher+"\t");
    
    }}
