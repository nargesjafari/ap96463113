/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectjava;

import java.util.Scanner;

/**
 *
 * @author narges
 */
public class student {
    String id,name,lesson,room;
    int age,grade;
    void new_student(){
      Scanner input=new Scanner(System.in);
        System.out.println("id");
        id=input.nextLine();
        System.out.println("name");
        name=input.nextLine();
        System.out.println("lesson");
        lesson=input.nextLine();
        System.out.println("room");
        room=input.nextLine();
        System.out.println("age  ");
        age=input.nextInt();    
         System.out.println("grade  ");
        grade=input.nextInt();    
    }
    void student_info(){
        System.out.println(id+"\t"+name+"\t"+lesson+"\t"+age+"\t"+grade);
    
    }}
