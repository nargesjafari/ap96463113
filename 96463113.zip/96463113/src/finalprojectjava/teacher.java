/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectjava;

import java.util.Scanner;

/**
 *
 * @author narges
 */
public class teacher extends student{
    String id,name,lesson;
    int room,age;
    void new_teacher(){
        Scanner input=new Scanner(System.in);
        System.out.println("id");
        id=input.nextLine();
        System.out.println("name");
        name=input.nextLine();
        System.out.println("lesson");
        lesson=input.nextLine();
        System.out.println("room  ");
        room=input.nextInt();
        System.out.println("age  ");
        age=input.nextInt();
    }
    void teacher_info(){
        System.out.println(id+"\t"+name+"\t"+lesson+"\t"+room+"\t"+age+"\t");
    }
    
    
}
