
package sherkat;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Sherkat {
    public static void main(String[] args) {
    String time1;
    String[] time1_arr=null;
    Scanner input=new Scanner(System.in);
    Scanner input1=new Scanner (System.in);
    user use=null;
    while(true){
    String order=input.nextLine();
    if(order.equals("join")){
     

     System.out.println("enter your name");
      String name = input.nextLine();
                System.out.println("Enter your id : ");
                long id= input1.nextLong();
                use= new user(name,id);
                Calendar cal = Calendar.getInstance();
                DateFormat dateFormat = new SimpleDateFormat("HH:mm");
                time1 = dateFormat.format(cal.getTime()).toString();
                time1_arr = time1.split(":");
    
    System.out.println("your joining time is : "+time1) ;
     }else if (order.equals("food")){
                System.out.println("Enter your  food name");
                String food = input.nextLine();
                use.reserv(food);
     }
     else if(order.equals("exit")){
         Calendar cal = Calendar.getInstance();
                DateFormat dateFormat = new SimpleDateFormat("HH:mm");
                String time2 = dateFormat.format(cal.getTime()).toString();
                String[] time2_arr = time2.split(":"); 
                int hour = Integer.parseInt(time2_arr[0])-Integer.parseInt(time1_arr[0]);
                int min = Integer.parseInt(time2_arr[1])-Integer.parseInt(time1_arr[1]);
                System.out.println("you where join for "+hour+":"+min);
                      
     }
    
     if(order.equals("order")){
    System.out.println("enter your morekhasi");
    String morekhasi=input.nextLine();
    use.take();
     }
    }
     }        

  
}

    


    

