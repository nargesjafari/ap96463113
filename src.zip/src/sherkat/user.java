
package sherkat;
public class user {
     private String name_a;
    private long id;
    private int tedad_morekhasi=0;
private int  tedad_food;
private String food;
    public user(String name , long id) {
        this.id = id;
       this. name_a= name;

    }  
   
    public void reserv(String food){
        this.food = food;
        System.out.println("food reserve for you");
    }
public  void take(){
 if(tedad_morekhasi<4){
     System.out.println(" morekhasi  reserv for you");
     tedad_morekhasi+=1;
           }
 else{
     System.out.println("morekhasi  not reserve for you");  
 }
    
}

    public long getter(){
        return this.id;
    }

    public String getName_a() {
        return name_a;
    }
     public void setName_a(String name_a) {
        if (!name_a.equals("@")){
            this.name_a = name_a;
        }}}


    




