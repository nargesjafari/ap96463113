
package assignment_7;

public class Assignment_7 {

    public static void main(String[] args) {
        double width=5;
        double length=7;
        Shape rectangle=new Rectangle(width,length);
        System.out.println("Rectangle width"+width+"Rectangle length"+length+"area"+rectangle.area()+"primeter"+rectangle.perimeter()+"\n");
      double radius=5;
      Shape circle=new Circle(radius);
        System.out.println("circle radius"+ radius+" Area"+circle.area()+"circle primeter"+circle.perimeter()+"\n");
        double row=4;
        Shape squre=new Square(row);
        System.out.println("squre"+squre+" area"+squre.area()+" primeter"+squre.perimeter()+"\n");
    }
    
}
