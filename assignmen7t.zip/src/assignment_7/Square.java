
package assignment_7;

public class Square extends Shape{
private final  double row;
public Square(){
this(1) ;   
}
public Square(double row){
 this.row=row;
}
    @Override
    public double area() {
        return row*row;
    }

    @Override
    public double perimeter() {
    return 4*row;
    }
    
}
