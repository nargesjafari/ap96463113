/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_7;

public class  Circle  extends Shape{
private final double radius;
final double pi=Math.PI;
public Circle(){
 this(1) ;  
}
public Circle(double radius){
 this.radius=radius;   
}
        
    @Override
    public double area() {
 return pi*Math.pow(radius, 2);
    }

    @Override
    public double perimeter() {
        return 2*pi*radius;
    }
    
}
